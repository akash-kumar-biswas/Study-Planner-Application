/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studyplannerapplication;

import java.util.Date;

/**
 *
 * @author Akash Biswas
 */
public class planData {

    private Integer planID;
    private String plan;
    private Date startDate;
    private Date endDate;
    private Date dateCreated;
    private String status;
    private String planner;

    public planData(Integer planID, String plan, Date startDate, Date endDate,Date dateCreated, String status, String planner) {
        this.planID = planID;
        this.plan = plan;
        this.startDate = startDate;
        this.endDate = endDate;
        this.dateCreated = dateCreated;
        this.status = status;
        this.planner = planner;
    }

    public Integer getPlanID() {
        return planID;
    }

    public String getPlans() {
        return plan;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

      public Date getDateCreated() {
        return dateCreated;
    }

    public String getStatus() {
        return status;
    }
    
    public String getPlanner() {
        return planner;
    }
}
